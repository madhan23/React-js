import React from 'react';
import './PlayerInfo.css';
function PlayerInfo(props){
return(
<div className="playerinfo_blk">
Name:{props.name}<br/><br/>
DOB:{props.dob}<br/><br/>
Age:{props.age}<br/><br/>
Role:{props.role}<br/><br/>

</div>
)
}
export default PlayerInfo;