import React, { Component } from 'react';
import './App.css';
import Player from './Compoents/Players';
import PlayerInfo from './Compoents/PlayerInfo';
class App extends Component {
  constructor(){
    super();
    this.state={
  records:[],
  playername: '',
  dob:'',
  age: '',
  role:'',
  information:'',
  status:true
}
this.updateData=this.updateData.bind(this);
this.store=this.store.bind(this);
this.deleteElement=this.deleteElement.bind(this);
this.PlayerInfo=this.PlayerInfo.bind(this);
}

updateData(event){
if(event.target.name==='playername')
this.setState({playername:event.target.value})
if(event.target.name==='dateofbirth')
this.setState({ dob:event.target.value})
if(event.target.name==='age')
this.setState({age:event.target.value})
if(event.target.name==='role')
this.setState({role:event.target.value})

}
store(){
 
  const newItem = {
    p_name: this.state.playername,
    p_dob: this.state.dob,
    p_age: this.state.age,
    p_role: this.state.role,
    id: Date.now()
  }



    this.setState(prevstate => ({
      records: [...prevstate.records,newItem],
      playername:'',
      dob:'',
      age: '',
      role:'',
  }));

}



deleteElement(id){

  let t=this.state.records;
var removeIndex = t.map(function(item) { 

  return item.id; 

}).indexOf(id);


t.splice(removeIndex, 1);
this.setState({
  records:t
})

}
PlayerInfo(playerdetail){

this.setState({
information:playerdetail

 })

 }

  render() {
    const playerdetails=this.state.records.map(name=>
      <Player 
      pname={name.p_name}
      remove={()=>this.deleteElement(name.id)}
      details={()=>this.PlayerInfo(name)}
      />

    )
   
 return (
<div className="container">
  <div className="entry">
 <h3>PlayerEntry</h3>    
    PLAYERNAME
     <input style={{height:'25px'}} type="text"
     name="playername"
     onChange={this.updateData}
     value={this.state.playername}
   /> <br/><br/>
        DOB<br/>
        <input style={{height:'25px',width:'170px'}} type="date"
        name="dateofbirth"
        onChange={this.updateData}
        value={this.state.dob}

   /> <br/><br/>
    AGE<br/>
        <input style={{height:'25px'}} type="text"
        name="age"
        onChange={this.updateData}
        value={this.state.age}

   /> <br/><br/>
    ROLE <br/>
    <select style={{height:'25px',width:'170px'}} name="role" onChange={this.updateData}  value={this.state.role}>
    <option value=""></option>
    <option value="Batsman">Batsman</option>
    <option value="Bowler">Bowler</option>
    <option value="AllRounder">AllRounder</option>
   </select> 
   <br/><br/>
   <button style={{height:'25px'}}
   onClick={this.store}>
    Add
   </button>
<br/><br/>

</div> 
<div className="sub-container">   
    <div className="sub1">   
    <center><h3 style={{color:'coral'}}>Players List</h3></center> 
   
        {playerdetails}
     
         
    </div>
    <div className="sub1">   
    <center><h3 style={{color:'coral'}}>Player Info</h3></center>  
    <PlayerInfo name={this.state.information.p_name} age={this.state.information.p_age} dob={this.state.information.p_dob} role={this.state.information.p_role} />
       
    </div>
</div>
</div> 

 );   
    
  }
}

export default App;
