import React from 'react';
import './Players.css';

function Players(props){

return (
<div className="playercontainer"onDoubleClick={props.deletevalue}style={props.styles?{color:'red'}:{color:'green'}}>
 <p onMouseOver={props.details} onClick={props.remove}>
    {props.pname} 
   
   
   </p>


</div>

)
}
export default Players;